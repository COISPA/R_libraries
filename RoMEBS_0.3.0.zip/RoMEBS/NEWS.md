NEWS
================
Walter Zupa - COISPA
01 February 2021

Fixes 0.1.1
-----
- 0.2.02 Modification of functions working on TE table to also work on the TE format for rapa whelk.
