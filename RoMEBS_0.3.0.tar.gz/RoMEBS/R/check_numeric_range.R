

check_numeric_range <- function(DataTA, Field, Values, wd, suffix) {


  if (FALSE) {
    DataTA = ta #ResultDataTA
    Field = "BOTTOM_SALINITY_END"
    Values = c(0,50)
  }



  if (!file.exists(file.path(wd, "Logfiles"))){
    dir.create(file.path(wd, "Logfiles"), showWarnings = FALSE)
  }
  numberError = 0
  if (!exists("suffix")){
    suffix=paste(as.character(Sys.Date()),format(Sys.time(), "_time_h%Hm%Ms%OS0"),sep="")
  }
  Errors <- file.path(wd,"Logfiles",paste("Logfile_", suffix ,".dat",sep=""))
  if (!file.exists(Errors)){
    file.create(Errors)
  }

  Result = DataTA
  write(paste("\n----------- check range of values for field:", Field, "-", Result$YEAR[1]), file = Errors, append = TRUE)

  Valuesf <- as.numeric(Values)
  lrange <- length(Valuesf)

  # # check NA values in the field (generate Error)
  # if (any(is.na(Result[, which(colnames(Result)==Field)]))){
  #   na.results <- Result[ is.na(Result[, which(colnames(Result)==Field)]) , ]
  #   l.na <- nrow(na.results)
  #   for (x.na in 1:l.na){
  #     write(paste("Haul",na.results$HAUL_NUMBER[x.na], ": value not allowed for", Field, "in",  na.results$TYPE_OF_FILE[1]), file = Errors, append = TRUE)
  #     numberError = numberError +1
  #   }
  # }
  Result <- Result[ !is.na(Result[, which(colnames(Result)==Field)]) , ]
  indexcol= which(names(Result)==Field)

  if ( (nrow(Result)!=0)){
    if (lrange == 2){
      k=1
        for (k in 1:nrow(Result)){
           if (!(Result[k, indexcol] >= Valuesf[1] & Result[k, indexcol] <= Valuesf[2])) {
             write(paste("Warning: Haul",Result$HAUL_NUMBER[k], ": value (",Result[k, indexcol],") out of allowed range for", Field, "in",  DataTA$TYPE_OF_FILE[1]), file = Errors, append = TRUE)
           }

        } # ciclo for
    } else if (lrange > 2) {
      k=1
      for (k in 1:nrow(Result)){
        if (!((Result[k, indexcol] >= Valuesf[1] & Result[k, indexcol] <= Valuesf[2]) |
             Result[k, indexcol] %in% Valuesf[3:lrange])) {

          write(paste("Warning: Haul",Result$HAUL_NUMBER[k], ": value (",Result[k, indexcol],") out of allowed range for", Field, "in",  DataTA$TYPE_OF_FILE[1]), file = Errors, append = TRUE)

        }

      } # ciclo for
      }
    }# nrow(Result)!=0

  if (numberError ==0) {
    write(paste("No error occurred for field", Field, "in",  DataTA$TYPE_OF_FILE[1]), file = Errors, append = TRUE)
  }

  if (file.exists(file.path(tempdir(), "Logfiles"))){
    unlink(file.path(tempdir(),"Logfiles"),recursive=T)
  }
  if (file.exists(file.path(tempdir(), "Graphs"))){
    unlink(file.path(tempdir(),"Graphs"),recursive=T)
  }
  if (file.exists(file.path(tempdir(), "files R-Sufi"))){
    unlink(file.path(tempdir(),"files R-Sufi"),recursive=T)
  }

  if (numberError ==0) {
    return(TRUE)
  } else { return(FALSE) }
}
