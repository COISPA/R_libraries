###########################################################################################################################
#   RoMEBS: R code to perform multiple checks on MEDITS Survey data (TA, TB, TC and TE files - old and new MEDITS formats)                                   #
#   Authors: I. Bitetto, W. Zupa, M.T. Spedicato                                                                    #
#   Coispa Tecnologia & Ricerca - Stazione sperimentale per lo Studio delle Risorse del Mare                              #
#   If you have any comments or suggestions please contact the following e-mail address: bitetto@coispa.it                #
#   March 2020
################################################################################
# Start depth and end depth of each haul should be in the same stratum



if (FALSE){
  ResultDataTA = read.csv("C:/Users/Bitetto Isabella/OneDrive - Coispa Tecnologia & Ricerca S.C.A.R.L/Rome/ROME/data/TA_GSA18_1994-2018.csv", sep=";")
  ResultDataTA=ResultDataTA[ResultDataTA$YEAR==1994,]
  #ResultTB = read.csv("C:/Users/Bitetto Isabella/OneDrive - Coispa Tecnologia & Ricerca S.C.A.R.L/Rome/ROME/data/TB_GSA18_1994-2018.csv", sep=";")

  wd <- "C:/Users/Bitetto Isabella/OneDrive - Coispa Tecnologia & Ricerca S.C.A.R.L/Rome/ROME/temp"
  suffix=paste(as.character(Sys.Date()),format(Sys.time(), "_time_h%Hm%Ms%OS0"),sep="")
  #load("C:/Users/Bitetto Isabella/OneDrive - Coispa Tecnologia & Ricerca S.C.A.R.L/Rome/ROME//RoME//data//DataTargetSpecies.rda")
  #load("C:/Users/Bitetto Isabella/OneDrive - Coispa Tecnologia & Ricerca S.C.A.R.L/Rome/ROME//RoME//data//Maturity_parameters.rda")
  #load("C:/Users/Bitetto Isabella/OneDrive - Coispa Tecnologia & Ricerca S.C.A.R.L/Rome/ROME//RoME//data//TM_list.rda")
  check_stratum(ResultDataTA,wd,suffix)
}


check_stratum<-function(ResultData,wd,suffix, Stratification=RoMEBS::Stratification){

  if (FALSE)  {
    ResultData = RoMEBS::TA
    wd=tempdir()
    suffix= "2020-03-05_time_h17m44s55"
    Stratification=RoMEBS::Stratification
  }

  Format="from_2012"
  if (!file.exists(file.path(wd, "Logfiles"))){
    dir.create(file.path(wd, "Logfiles"), showWarnings = FALSE)
  }
  if (!exists("suffix")){
    suffix=paste(as.character(Sys.Date()),format(Sys.time(), "_time_h%Hm%Ms%OS0"),sep="")
  }
  numberError = 0
  Errors <- file.path(wd,"Logfiles",paste("Logfile_",suffix,".dat",sep=""))
  if (!file.exists(Errors)){
    file.create(Errors)
  }

  #ResultData = read.csv(paste(Data,".csv",sep=""), sep=";", header=TRUE)
  write(paste("\n----------- check start depth and end depth in the same stratum TA - ",ResultData$YEAR[1]), file = Errors, append = TRUE)

  ResultData=ResultData[ResultData$VALIDITY=="V",]

  GSA <- unique(ResultData$AREA)
  COUNTRY <- unique(ResultData$COUNTRY)
  Strata <- Stratification[Stratification$GSA %in% GSA & Stratification$COUNTRY %in% COUNTRY,  ]
  str.codes <- sort(unique(Strata$CODE))
  nstrata = length(str.codes)

  ResultData$stratum_s <- 0
  ResultData$stratum_e <- 0

  i=1
  for (i in 1:nrow(ResultData)){

    if ((ResultData$SHOOTING_DEPTH[i]) > Strata[Strata$CODE == nstrata[length(nstrata)], "MAX_DEPTH"][1])
        {
          write(paste("Warning: Haul", ResultData$HAUL_NUMBER[i]," start depth (",ResultData$SHOOTING_DEPTH[i],"m ) is out of the depth stratification range."), file = Errors, append = TRUE)
        }
    s=1
    for (s in 1:nstrata) {


        if ((ResultData$SHOOTING_DEPTH[i]> Strata[Strata$CODE == str.codes[s], "MIN_DEPTH"][1]) & (ResultData$SHOOTING_DEPTH[i]<=Strata[Strata$CODE == str.codes[s], "MAX_DEPTH"][1]))
        {
          ResultData$stratum_s[i]=str.codes[s]
        }
      }
  }
  for (j in 1:nrow(ResultData)){
    if ((ResultData$HAULING_DEPTH[j]) > Strata[Strata$CODE == nstrata[length(nstrata)], "MAX_DEPTH"][1])
      {
          write(paste("Warning: Haul",ResultData$HAUL_NUMBER[j]," final depth (",ResultData$HAULING_DEPTH[j],"m ) is out of the depth stratification range."), file = Errors, append = TRUE)
      }

    for (s in 1:nstrata) {
      if ((ResultData$HAULING_DEPTH[j]> Strata[Strata$CODE == str.codes[s], "MIN_DEPTH"][1]) & (ResultData$HAULING_DEPTH[j]<=Strata[Strata$CODE == str.codes[s], "MAX_DEPTH"][1]))
      {
        ResultData$stratum_e[j]=str.codes[s]
      }
    }
  }


  for (k in 1:nrow(ResultData)){
    if (ResultData$stratum_s[k]!= ResultData$stratum_e[k]){
      write(paste("Warning: Haul",ResultData$HAUL_NUMBER[k]," starts in the stratum",ResultData$stratum_s[k],"(",ResultData$SHOOTING_DEPTH[k],"m ) and finishes in the stratum", ResultData$stratum_e[k],"(",ResultData$HAULING_DEPTH[k],"m ) in",ResultData$TYPE_OF_FILE[k]), file = Errors, append = TRUE)}
  }

  if (numberError ==0) {
    write(paste("No error occurred"), file = Errors, append = TRUE)
  }
   if (file.exists(file.path(tempdir(), "Logfiles"))){
  unlink(file.path(tempdir(),"Logfiles"),recursive=T)
  }
  if (file.exists(file.path(tempdir(), "Graphs"))){
  unlink(file.path(tempdir(),"Graphs"),recursive=T)
    }
	if (file.exists(file.path(tempdir(), "files R-Sufi"))){
  unlink(file.path(tempdir(),"files R-Sufi"),recursive=T)
    }
  if (numberError ==0) {
    return(TRUE)
  } else { return(FALSE) }
}
