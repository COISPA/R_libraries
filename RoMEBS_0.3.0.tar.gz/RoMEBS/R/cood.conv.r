cood.conv <- function (x,y,q=NA,type=1)
{
  if (FALSE) {
    ta <- TA # MEDITS.to.dd(TA)
    x=ta$SHOOTING_LONGITUDE
    y=ta$SHOOTING_LATITUDE
    q=ta$SHOOTING_QUADRANT*7
    cood.conv(x,y,q,2)
  }

  if(length(x)!=length(y)) { stop("x and y have different length")}
  if (type !=1 & type!=2)  { stop("'type' value not allowed")}
  if (any(!(q %in% c(1,3,5,7,NA)))) { stop("'q' value/values not allowed")}
  if (type==1){  # dd to MEDITS
  sx <- rep(NA, length(x))
  sy <- rep(NA, length(y))
  sx[which(x>=0)] <- "+"
  sx[which(x<0)] <- "-"
  sy[which(y>=0)] <- "+"
  sy[which(y<0)] <- "-"
  q <- rep(NA, length(x))
  for (i in 1 :length(x)) {
    if (sx[i]=="+" & sy[i]=="+") {
      q[i] <- 1
    } else if (sx[i]=="+" & sy[i]=="-"){
      q[i] <- 3
    } else if (sx[i]=="4" & sy[i]=="-"){
      q[i] <- 5
    } else if (sx[i]=="-" & sy[i]=="+"){
      q[i] <- 7
    }
  }
  deg <- floor(x)
  dec <- x - (deg)
  dd <- (deg * 100) + (dec * 60)
  x <- abs(dd)
  deg <- y
  dec <- y - (deg)
  dd <- (deg * 100) + (dec * 60)
  y <- abs(dd)
  data<- data.frame(x=x,y=y,quadrant=q)
  } else if (type == 2) {   # MEDITS to dd
    if(length(x)!=length(q)) { stop("q and x have different length")}
    if(length(y)!=length(q)) { stop("q and y have different length")}
    lon_start = x
    lat_start = y
    LonStartDeg = floor(floor(x)/100)
    LatStartDeg = floor(floor(y)/100)
    LonStartMin = (lon_start - LonStartDeg * 100)/60
    LatStartMin = (lat_start - LatStartDeg * 100)/60
    lon_start2 = LonStartDeg + LonStartMin
    lat_start2 = LatStartDeg + LatStartMin
    x = lon_start2
    y = lat_start2

    k <- 1
    for (k in 1:length(q)) {
      if (q[k] == 7) {
       x[k] <- -1 * x[k]
      }
      if (q[k] == 3) {
        y[k] <- -1 * y[k]
      }
      if (q[k] == 5) {
        x[k] <- -1 * x[k]
        y[k] <- -1 * y[k]
      }
    }
    data <- data.frame(x=x,y=y)
  }
  return(data)
}
