RoMEBS.wizard <- function() {

  message("Select a suitable working directory.\n")
  wd <- tcltk::tk_choose.dir(getwd(), "Select the working directory")
  setwd(wd)

  #######  Defaults #######
  suffix=NA
  verbose = TRUE
  #########################

  tcltk::tk_messageBox(type="ok",message="Select TA, TB and TC csv file\n(use semicolumn ';' as separator)")
  ## TA
  ta.file=tcltk::tclvalue(tcltk::tkgetOpenFile(filetypes = "{ {CSV Files} {.csv} }",title="Select TA file"))
  ta <- utils::read.table(ta.file,sep=";",header = T)
  if (!is.null(checkHeader(ta,"TA"))){
    stop("Unexpected headers in the selected TA file.")
  }

  ## TB
  tb.file=tcltk::tclvalue(tcltk::tkgetOpenFile(filetypes = "{ {CSV Files} {.csv} }",title="Select TB file"))
  tb <- utils::read.table(tb.file,sep=";",header = T)
  if (!is.null(checkHeader(tb,"TB"))){
    stop("Unexpected headers in the selected TB file.")
  }

  ## TC
  tc.file=tcltk::tclvalue(tcltk::tkgetOpenFile(filetypes = "{ {CSV Files} {.csv} }",title="Select TC file"))
  tc <- utils::read.table(tc.file,sep=";",header = T)
  if (!is.null(checkHeader(tc,"TC"))){
    stop("Unexpected headers in the selected TC file.")
  }


  # TE loading
  TE_upload <- tcltk::tk_messageBox(type="yesno",message="Do you want to check also TE table?", default="no")
  if (TE_upload == "yes")
    {
    ## TE
      te.file=tcltk::tclvalue(tcltk::tkgetOpenFile(filetypes = "{ {CSV Files} {.csv} }",title="Select TE file"))
      te <- utils::read.table(te.file,sep=";",header = T)
      TE_type <- unique(ta$GEAR)
      if (TE_type %in% c("GOC73", "TRAWL")){
        if (!is.null(checkHeader(te,"TE"))){
          stop("Unexpected headers in the selected TE file.")
        }
      } else if (TE_type %in% c("BEAMT", "TBB")) {
        if (!is.null(checkHeader(te,"TE", TE_format="rapana"))){
          stop("Unexpected headers in the selected TE file.")
        }
      }
  } else {
    te <- NA
  }

  # TL loading
  TL_upload <- tcltk::tk_messageBox(type="yesno",message="Do you want to check also TL table?", default="no")
  if (TL_upload == "yes")
  {
    ## TL
      tl.file=tcltk::tclvalue(tcltk::tkgetOpenFile(filetypes = "{ {CSV Files} {.csv} }",title="Select TL file"))
      tl <- utils::read.table(tl.file,sep=";",header = T)
      if (!is.null(checkHeader(tl,"TL"))){
        stop("Unexpected headers in the selected TL file.")
      }
  } else {
    tl <- NA
  }

  ### creation of 'Tables' folder
  if (!file.exists(file.path(wd, "Tables"))){
    dir.create(file.path(wd, "Tables"), showWarnings = FALSE)
    write.table(RoMEBS::Stratification, file.path(wd, "Tables/Stratification.csv"), sep=";", row.names=FALSE)
    write.table(RoMEBS::TM_list , file.path(wd, "Tables/TM_list.csv"), sep=";", row.names=FALSE)
    write.table(RoMEBS::DataTargetSpecies , file.path(wd, "Tables/DataTargetSpecies.csv"), sep=";", row.names=FALSE)
    write.table(RoMEBS::Maturity_parameters , file.path(wd, "Tables/Maturity_parameters.csv"), sep=";", row.names=FALSE)
    write.table(RoMEBS::mat_stages , file.path(wd, "Tables/mat_stages.csv"), sep=";", row.names=FALSE)
    write.table(RoMEBS::list_g1_g2 , file.path(wd, "Tables/list_g1_g2.csv"), sep=";", row.names=FALSE)
    write.table(RoMEBS::LW , file.path(wd, "Tables/LW.csv"), sep=";", row.names=FALSE)
  }

  ### Saving tables in 'Tables' folder

  tcltk::tk_messageBox(type="ok","A copy of the dictionary' tables is saved in 'Tables' folder. If needed, you can modify one or more tables.")

  ### Tables update
  update <- tcltk::tk_messageBox(type="yesno",message="Do you want to update one or more tables saved in 'Tables' folder?", default="no")

  if (update=="yes") {
    Stratification_new <- read.table(file.path(wd, "Tables/Stratification.csv"), sep=";", header=T)
    TM_list_new <- read.table(file.path(wd, "Tables/TM_list.csv"), sep=";", header=T)
    DataTargetSpecies_new <- read.table(file.path(wd, "Tables/DataTargetSpecies.csv"), sep=";", header=T)
    Maturity_parameters_new <- read.table(file.path(wd, "Tables/Maturity_parameters.csv"), sep=";", header=T)
    mat_stages_new <- read.table(file.path(wd, "Tables/mat_stages.csv"), sep=";", header=T)
    list_g1_g2_new <- read.table(file.path(wd, "Tables/list_g1_g2.csv"), sep=";", header=T)
    LW_new <- read.table(file.path(wd, "Tables/LW.csv"), sep=";", header=T)
  }

# RUN RoMEBS function
if (update=="no") {
RoMEBS(TA=ta,
     TB=tb,
     TC=tc,
     TE=te,
     TL=tl,
     wd=wd,
     suffix=suffix,
     verbose=verbose,
     Strata=RoMEBS::Stratification,
     Ref_list=RoMEBS::TM_list,
     TargetSpecies=RoMEBS::DataTargetSpecies,
     LW_table = RoMEBS::LW,
     Maturity=RoMEBS::Maturity_parameters,
     mstages=RoMEBS::mat_stages,
     ass_TL=RoMEBS::assTL)
}

if (update == "yes") {
  RoMEBS(TA=ta,
       TB=tb,
       TC=tc,
       TE=te,
       TL=tl,
       wd=wd,
       suffix=suffix,
       verbose=verbose,
       Strata=Stratification_new ,
       Ref_list=TM_list_new,
       TargetSpecies=DataTargetSpecies_new,
       LW_table = LW_new,
       Maturity=Maturity_parameters_new,
       mstages=mat_stages_new,
       ass_TL=RoMEBS::assTL)
}

}

